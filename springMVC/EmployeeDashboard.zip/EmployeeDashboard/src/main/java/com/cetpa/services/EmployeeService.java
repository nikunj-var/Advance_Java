package com.cetpa.services;


public interface EmployeeService {
	

}
