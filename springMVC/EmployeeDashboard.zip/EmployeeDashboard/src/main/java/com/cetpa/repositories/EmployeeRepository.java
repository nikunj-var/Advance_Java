package com.cetpa.repositories;

public interface EmployeeRepository {

}
